/**
 * Common Utils 
 */
declare var jQuery: any;

export class CommonUtils {

    /**
     * trim white spaces on keypress
     */ 
    static trimWhiteSpacesOnKeyPress() {
        jQuery('input[type=text],input[type=email]').keyup(function () {
            jQuery(this).val(jQuery(this).val().replace(/ +?/g, ''));
        });
    }

    /**
     * trim white spaces on blur
     */
    static trimWhiteSpacesOnBlur(){
       jQuery('input[type=email]').keyup(function(){
           jQuery(this).val(jQuery(this).val().replace(/ +?/g, ''));
       })
    }

    /**
     * Active progress animation
     */
    static activeProgressBar(){
        var total = 4;
        var current = parseInt(jQuery('.page-heading-mobile').attr('data-step'));
        var average  = (current/total)*100;
        var activePercent = average + '%';
        var progress = jQuery('.progress-bar');
        jQuery('.progress-bar').attr('data-progress1',average);
         progress.css('width',activePercent);
         //progress.animate({ width: activePercent }, { duration: 1500, easing: 'linear' })
    }

    /**
     * Completed progress bar by step number
     */
    static completedProgressBarStep(current){
        var total = 4;    
        var average  = (current/total)*100;
        var activePercent = average + '%';
        var progress = jQuery('.progress-bar2');
        jQuery('.progress-bar2').attr('data-progress2',average);
       // progress.css('width',activePercent);
        progress.animate({ width: activePercent }, { duration: 1500, easing: 'linear' })
    }

    
    /**
     * Active progress bar by step number
     */
    static activeProgressBarStep(current){
        var total = 4;
       // var current = parseInt(jQuery('.page-heading-mobile').attr('data-step'));
        var average  = (current/total)*100;
        var activePercent = average + '%';
        var progress = jQuery('.progress-bar');
        jQuery('.progress-bar').attr('data-progress1',average);
         progress.css('width',activePercent);
         //progress.animate({ width: activePercent }, { duration: 1500, easing: 'linear' })
    }

}