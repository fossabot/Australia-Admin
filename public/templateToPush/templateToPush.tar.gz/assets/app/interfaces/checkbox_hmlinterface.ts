export class checkbox_hml {
    constructor(
        public aus_citizen_hml: Boolean,
        public age_test_hml: Boolean
    ) {
        this.aus_citizen_hml = aus_citizen_hml;
        this.age_test_hml = age_test_hml;
    }
}
