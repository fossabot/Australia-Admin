export class checkbox_prl {
    constructor(
         public aus_citizen_prl: Boolean,
        public age_test_prl: Boolean
    ) {
          this.aus_citizen_prl = aus_citizen_prl;
        this.age_test_prl = age_test_prl;
    }
}