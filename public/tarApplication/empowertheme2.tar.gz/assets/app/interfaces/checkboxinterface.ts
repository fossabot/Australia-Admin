export class checkbox{
    constructor(
         public aus_citizen:Boolean,
        public age_test: Boolean
    ){
        this.aus_citizen=aus_citizen;
        this.age_test=age_test;
    }
}