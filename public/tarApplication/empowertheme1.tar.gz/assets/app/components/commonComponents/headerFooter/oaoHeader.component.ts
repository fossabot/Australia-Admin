import { Component ,AfterViewInit,OnInit} from '@angular/core';
import {Router} from '@angular/router'
import { OAOService } from "../../../services/OAO.Service";
declare var jQuery:any;
@Component({
    selector: 'oao-header',
    templateUrl: './oaoHeader.component.html'
    
})
export class oaoHeaderComponent{
	constructor(private oaoService: OAOService){}
    clear(){
        window.location.href=this.oaoService.baseURL;
        localStorage.clear();
    }
}