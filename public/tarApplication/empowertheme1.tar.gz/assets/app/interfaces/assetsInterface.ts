export class Assetdetails {
    constructor(
          public assettype:string,
          public assetvalue:string
    ){
        this.assettype=assettype
        this.assetvalue=assetvalue
      
    }
}