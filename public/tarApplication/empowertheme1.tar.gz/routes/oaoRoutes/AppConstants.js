
exports.ACTIVE='SAV';
// const ACTIVE= "SAV";

exports.INCOMPLETE = "INC";

exports.COMPLETED = "CMP";

exports.VERIFIED = "VER";

exports.CANCELLED = "CAN";

exports.REJECTED = "REJ";

exports.ONBOARDED = "ONB";


